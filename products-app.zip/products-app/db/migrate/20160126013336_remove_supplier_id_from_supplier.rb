class RemoveSupplierIdFromSupplier < ActiveRecord::Migration
 
end
