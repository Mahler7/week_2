class AddChangeTypesToProducts < ActiveRecord::Migration
  def change
    change_table :products do |t|
      t.change :description, :text
      t.change :price, :decimal
      t.change :quantity, :integer
    end
  end
end
