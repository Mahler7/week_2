Supplier.create!([
  {name: "Winter Product Land", email: "info@wpl.com", phone: "800-355-9876"}
  ])


