class ProductsController < ApplicationController

  def index
    @products = Product.all

    # if params[:sort] && params[:sort_order]
    #   @tacos = Product.order(params[:sort] => params[:sort_order]) - combines first and second if statements below (uses different params)

    if params[:low]
      @products = Product.order(:price)
      # @products = Product.order(params[:low]) Teacher
    elsif params[:high]
      @products = Product.order(price: :desc)
      # @products = Product.order(params[:high] => :desc) Teacher
    elsif params[:discount]
      @products = Product.where("price < ?", 2)
      # @products = Product.where("price < ?", params[:discount]
    end
  end

  def show
    @product = Product.find_by(id: params[:id])
    @supplier = @product.supplier
  end

  def new 

  end

  def create
    @products = Product.create({name: params[:name],
                                description: params[:description],
                                price: params[:price],
                                quantity: params[:quantity]})

    Image.create({image: params[:image], product_id: @products.id})
    flash[:success] = "New Product Created"

    redirect_to "/products"
  end

  def edit
    @products = Product.find(params[:id])
  end

  def update
    @products = Product.find(params[:id])

    @products.update({name: params[:name],
                                description: params[:description],
                                price: params[:price],
                                quantity: params[:quantity]})

    Image.create({image: params[:image], product_id: @products.id})
    
    flash[:success] = "Product Updated"

    redirect_to "/products"
  end

  def destroy
    @products = Product.find(params[:id])
    @products.destroy

    flash[:warning] = "Product Destroyed"

    redirect_to "/products"
  end

  def random
    @product = Product.all.sample

    # redirect_to "/products/#{product.id}"
    render :show #like redirect
  end

  def search
    @products = Product.where("name LIKE ? OR description LIKE ?", "%#{params[:search]}%", "%#{params[:search]}%")

    render :index
  end


  
end
