class Product < ActiveRecord::Base

  belongs_to :supplier 
  has_many :orders
  has_many :images

  def sale_message
    if price.to_i < 2
      message = "Discount Item"
    else 
      message = "On Sale!"
    end
    message
  end

  def tax
    tax_rate = price.to_f * 0.09
  end

  def total
    price.to_f + tax
  end

  # def get_the_first_image
  #   if images.first != nil
  #     images.first.url
  #   else
  #     Image.first.url
  #   end
  # end
end
